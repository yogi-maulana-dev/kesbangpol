"use strict";
$(document).ready(function() {
	// Single swithces
	var elemsingle = document.querySelector('.js-single');
	var switchery = new Switchery(elemsingle, { color: '#4680ff', jackColor: '#fff' });
});