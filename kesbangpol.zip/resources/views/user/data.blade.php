@extends('layouts.main_admin')

@section('data')

data
    
@endsection