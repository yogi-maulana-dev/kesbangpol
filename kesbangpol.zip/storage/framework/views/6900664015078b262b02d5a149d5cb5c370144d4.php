<?php $__env->startSection('dashboard'); ?>
    <style>
        .modal {
            overflow-y: auto;
        }

    </style>

    <?php if($datas->isEmpty()): ?>
        <div class="card">
            <div class="card-header">
                <h5>Halaman Data Pendaftaran Organisasi Masyarakat</h5>
                <!--<span>Add class of <code>.form-control required</code> with <code>&lt;input&gt;</code> tag</span>-->
            </div>
            <div class="card-block">
                <form method="post" action="/data" class="form-material" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Tujuan Organisasi</label>
                        <div class="col-sm-8">
                            <input type="file" name="tujuan" class="form-control <?php $__errorArgs = ['tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Program Organiasi</label>
                        <div class="col-sm-8">
                            <input type="file" name="program" class="form-control <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Pendaftaran</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_pendaftaran"
                                class="form-control <?php $__errorArgs = ['surat_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['surat_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Akte Pendirian</label>
                        <div class="col-sm-8">
                            <input type="file" name="akte_pendirian"
                                class="form-control <?php $__errorArgs = ['akte_pendirian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['akte_pendirian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        </div>
                    </div>



                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Anggaran rumah Tangga</label>
                        <div class="col-sm-8">
                            <input type="file" name="adrt" class="form-control <?php $__errorArgs = ['adrt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['adrt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Keputusan susunan Pengurus Orkermas secara
                            lengkap</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_keputusan"
                                class="form-control <?php $__errorArgs = ['surat_keputusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['surat_keputusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Biodata Pengurus</label>
                        <div class="col-sm-8">
                            <input type="file" name="biodata_pengurus"
                                class="form-control <?php $__errorArgs = ['biodata_pengurus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['biodata_pengurus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">KTP</label>
                        <div class="col-sm-8">
                            <input type="file" name="ktp" class="form-control <?php $__errorArgs = ['ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Foto</label>
                        <div class="col-sm-8">
                            <input type="file" name="foto" class="form-control <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Keterangan Domisili</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_keterangan_domisili"
                                class="form-control <?php $__errorArgs = ['surat_keterangan_domisili'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['surat_keterangan_domisili'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">NPWP Organisasi</label>
                        <div class="col-sm-8">
                            <input type="file" name="npwp" class="form-control <?php $__errorArgs = ['npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Foto Kantor Tampak Depan papan nama organisasi</label>
                        <div class="col-sm-8">
                            <input type="file" name="foto_kantor"
                                class="form-control <?php $__errorArgs = ['foto_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['foto_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Pernyataan Kesiapan menertibkan organisasi</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_ketertiban"
                                class="form-control <?php $__errorArgs = ['surat_ketertiban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['surat_ketertiban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Pernyataan Tidak Berafilasi dengan partai politik
                            ditanda tangani ketua</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_tidak_avilasi"
                                class="form-control <?php $__errorArgs = ['surat_tidak_avilasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['surat_tidak_avilasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Pernyataan Tidak Tejadi Konflik pengurusan ditanda
                            tangani ketua</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_konflik"
                                class="form-control <?php $__errorArgs = ['surat_konflik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"> <?php $__errorArgs = ['surat_konflik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Pernyataan Hak Cipta Simbol Organisasi ditanda tangani
                            ketua dan seketaris</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_hak_cipta"
                                class="form-control <?php $__errorArgs = ['surat_hak_cipta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['surat_hak_cipta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Pernyataan sanggup menyampaikan laporan ditanda tangani
                            ketua</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_laporan"
                                class="form-control <?php $__errorArgs = ['surat_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"> <?php $__errorArgs = ['surat_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Pernyataan bertanggung jawab keabsahan data ditanda
                            tangan ketua dan seketaris</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_absah"
                                class="form-control <?php $__errorArgs = ['surat_absah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"> <?php $__errorArgs = ['surat_absah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Rekomendasi dari kementrian agama untuk orkermas
                            keagamaan</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_rekom_agama"
                                class="form-control <?php $__errorArgs = ['surat_rekom_agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['surat_rekom_agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Rekomendasi dari kementrian dan SKPD bidang kebudayaan
                            khusus kepercayaan pada tuhan yang Maha Esa</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_rekom_skpd"
                                class="form-control <?php $__errorArgs = ['surat_rekom_skpd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['surat_rekom_skpd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat Rekomendasi dari kementrian dan SKPD bidang tenaga
                            kerja orkemas serikat buruh</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_rekom_skpd_kerja"
                                class="form-control <?php $__errorArgs = ['surat_rekom_skpd_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['surat_rekom_skpd_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat pernyataan persetujuan, untuk menyantumkan nama
                            anggota nama pejabat negara, pemerintahan, dan tokoh masyarakt</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_rekom_kesediaan"
                                class="form-control <?php $__errorArgs = ['surat_rekom_kesediaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['surat_rekom_kesediaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat pernyataan persetujuan, untuk menyantumkan nama
                            anggota nama pejabat negara, pemerintahan, dan tokoh masyarakt</label>
                        <div class="col-sm-8">
                            <input type="file" name="surat_izasah"
                                class="form-control <?php $__errorArgs = ['surat_izasah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['surat_izasah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Surat pernyataan persetujuan, untuk menyantumkan nama
                            anggota nama pejabat negara, pemerintahan, dan tokoh masyarakt</label>
                        <div class="col-sm-8">
                            <input type="file" name="skt" class="form-control <?php $__errorArgs = ['skt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['skt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="col-sm-10">
                        <button type="submit" class="btn btn-primary m-b-0">Submit</button>
                    </div>

            </div>


            </form>
        </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-block">

                <div class="card-header">
                    <h5>Data Organisasi Masyarakat Yang diajukan</h5>
                    <span>Data yang sudah dikirim akan di proses sampa 3 x 24 jam, jika ada kesalahan atau kekurangan data
                        mohon dilakukan pengirim data yang kurang sesuai syarat yang ada.</span>
                </div>
                <div class="card-block">
                    <div class="dt-responsive table-responsive">
                        <table id="new-cons" class="table table-striped table-bordered nowrap">
                            <thead>
                                <tr>
                                    <th>Nama Organisasi</th>
                                    <th>Tujuan</th>
                                    <th>Program</th>
                                    <th>Data Upload</i></th>
                                    <th>Status</i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(auth()->user()->nama); ?></td>
                                        <td><?php echo e($data->tujuan); ?></td>
                                        <td><?php echo e($data->program); ?></td>

                                        <td> <button
                                                class="btn waves-effect waves-dark btn-primary btn-outline-primary badge bg-info"
                                                data-toggle="modal" data-target="#tabbed-form"><span
                                                    data-feather="eye"></span></button>
                                            <a href="/data/<?php echo e($data->id); ?>/edit" class="badge bg-warning"><span
                                                    data-feather="edit"></span></a>
                                        </td>

                                        <td>
                                            <?php if($data->lengkap == 0): ?>
                                                <div class="label-main">
                                                    <label class="label label-lg label-primary"><i
                                                            class="fa fa-spinner"></i> Proses</label>

                                                </div>
                                            <?php else: ?>
                                                Sudah di verikasi
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- tabbed form modal end -->



        <div id="tabbed-form" class="modal fade mixed-form" role="dialog">
            <div class="modal-dialog">
                <div class="card">
                    <div class="card-body">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs md-tabs nav-justified" role="tablist">
                            <li class="nav-item waves-effect waves-dark">
                                <a class="nav-link active" data-toggle="tab" href="#data1" role="tab">
                                    <h6 class="m-b-0">Data 1</h6>
                                </a>
                                <div class="slide"></div>
                            </li>
                            <li class="nav-item waves-effect waves-dark">
                                <a class="nav-link" data-toggle="tab" href="#data2" role="tab">
                                    <h6 class="m-b-0">Data 2</h6>
                                </a>
                                <div class="slide"></div>
                            </li>

                            <li class="nav-item waves-effect waves-dark">
                                <a class="nav-link" data-toggle="tab" href="#data3" role="tab">
                                    <h6 class="m-b-0">Data 3</h6>
                                </a>
                                <div class="slide"></div>
                            </li>

                            <li class="nav-item waves-effect waves-dark">
                                <a class="nav-link" data-toggle="tab" href="#data4" role="tab">
                                    <h6 class="m-b-0">Data 4</h6>
                                </a>
                                <div class="slide"></div>
                            </li>
                        </ul>
                        <!-- Tab panes -->


                        <div class="tab-content p-t-30">
                            <div class="tab-pane active" id="data1" role="tabpanel">
                                <form class="md-float-material form-material">
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php if(!empty($data->surat_pendaftaran)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_pendaftaran);
                                                $surat_pendaftaran = $pecah[1];
                                            ?>

                                            

                                            <?php if($surat_pendaftaran == 'pdf'): ?>
                                                <?php if($data->a_surat_pendaftaran == 0): ?>
                                                    <p class="text-muted text-center p-b-5">
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_pendaftaran); ?></label>

                                                    </p>
                                                <?php elseif($data->a_surat_pendaftaran == 1): ?>
                                                    <p class="text-muted text-center p-b-5">

                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_pendaftaran); ?></label>

                                                    </p>
                                                <?php else: ?>
                                                    <label class="label label-inverse-danger"><span
                                                            data-feather="x-square"></span><?php echo e($data->surat_keputusan); ?></label>
                                                <?php endif; ?>

                                                

                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_pendaftaran"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_pendaftaran == 'png' or $surat_pendaftaran == 'jpg'): ?>
                                                

                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_pendaftaran == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_pendaftaran); ?></label>
                                                    <?php elseif($data->a_surat_pendaftaran == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_pendaftaran); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                


                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_pendaftaran)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_pendaftaran); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_pendaftaran)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        


                                        
                                        <?php if(!empty($data->akte_pendirian)): ?>
                                            <?php
                                                $pecah = explode('.', $data->akte_pendirian);
                                                $akte_pendirian = $pecah[1];
                                            ?>

                                            <?php if($akte_pendirian == 'pdf'): ?>
                                                

                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_akte_pendirian == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->akte_pendirian); ?></label>
                                                    <?php elseif($data->a_akte_pendirian == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->akte_pendirian); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#akte_pendirian"
                                                        class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($akte_pendirian == 'png' or $akte_pendirian == 'jpg'): ?>
                                                

                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_akte_pendirian == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->akte_pendirian); ?></label>
                                                    <?php elseif($data->a_akte_pendirian == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_pendaftaran); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->akte_pendirian)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->akte_pendirian); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->akte_pendirian)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        

                                        
                                        <?php if(!empty($data->adrt)): ?>
                                            <?php
                                                $pecah = explode('.', $data->adrt);
                                                $adrt = $pecah[1];
                                            ?>

                                            <?php if($adrt == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_adrt == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->adrt); ?></label>
                                                    <?php elseif($data->a_adrt == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->adrt); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#adrt" class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($adrt == 'png' or $adrt == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_adrt == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->adrt); ?></label>
                                                    <?php elseif($data->a_adrt == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->adrt); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->adrt)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->adrt); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->adrt)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        

                                        
                                        <?php if(!empty($data->surat_keputusan)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_keputusan);
                                                $surat_keputusan = $pecah[1];
                                            ?>

                                            <?php if($surat_keputusan == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_keputusan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_keputusan); ?></label>
                                                    <?php elseif($data->a_surat_keputusan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_keputusan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_keputusan"
                                                        class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($surat_keputusan == 'png' or $surat_keputusan == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_keputusan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_keputusan); ?></label>
                                                    <?php elseif($data->a_surat_keputusan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_keputusan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_keputusan)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_keputusan); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_keputusan)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        

                                        
                                        <?php if(!empty($data->biodata_pengurus)): ?>
                                            <?php
                                                $pecah = explode('.', $data->biodata_pengurus);
                                                $biodata_pengurus = $pecah[1];
                                            ?>

                                            <?php if($biodata_pengurus == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_biodata_pengurus == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->biodata_pengurus); ?></label>
                                                    <?php elseif($data->a_biodata_pengurus == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->biodata_pengurus); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#biodata_pengurus"
                                                        class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($biodata_pengurus == 'png' or $biodata_pengurus == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_biodata_pengurus == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->biodata_pengurus); ?></label>
                                                    <?php elseif($data->a_biodata_pengurus == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->biodata_pengurus); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->biodata_pengurus)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->biodata_pengurus); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->biodata_pengurus)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </form>
                            </div>
                            <div class="tab-pane" id="data2" role="tabpanel">
                                <form class="md-float-material form-material">
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php if(!empty($data->ktp)): ?>
                                            <?php
                                                $pecah = explode('.', $data->ktp);
                                                $ktp = $pecah[1];
                                            ?>

                                            <?php if($ktp == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_ktp == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->ktp); ?></label>
                                                    <?php elseif($data->a_ktp == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->ktp); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#ktp" class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($ktp == 'png' or $ktp == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_ktp == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->ktp); ?></label>
                                                    <?php elseif($data->a_ktp == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->ktp); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->ktp)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->ktp); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->ktp)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        

                                        
                                        <?php if(!empty($data->foto)): ?>
                                            <?php
                                                $pecah = explode('.', $data->foto);
                                                $foto = $pecah[1];
                                            ?>

                                            <?php if($foto == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_foto == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->foto); ?></label>
                                                    <?php elseif($data->a_foto == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->foto); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#foto" class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($foto == 'png' or $foto == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_foto == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->foto); ?></label>
                                                    <?php elseif($data->a_foto == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->foto); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->foto)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->foto); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->foto)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        

                                        
                                        <?php if(!empty($data->surat_keterangan_domisili)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_keterangan_domisili);
                                                $surat_keterangan_domisili = $pecah[1];
                                            ?>

                                            <?php if($surat_keterangan_domisili == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_keterangan_domisili == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_keterangan_domisili); ?></label>
                                                    <?php elseif($data->a_surat_keterangan_domisili == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_keterangan_domisili); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_keterangan_domisili"
                                                        class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($surat_keterangan_domisili == 'png' or $surat_keterangan_domisili == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_keterangan_domisili == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_keterangan_domisili); ?></label>
                                                    <?php elseif($data->a_surat_keterangan_domisili == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_keterangan_domisili); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_keterangan_domisili)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_keterangan_domisili); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_keterangan_domisili)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        

                                        
                                        <?php if(!empty($data->npwp)): ?>
                                            <?php
                                                $pecah = explode('.', $data->npwp);
                                                $npwp = $pecah[1];
                                            ?>

                                            <?php if($npwp == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_npwp == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->npwp); ?></label>
                                                    <?php elseif($data->a_npwp == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->npwp); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#npwp" class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($npwp == 'png' or $npwp == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_npwp == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->npwp); ?></label>
                                                    <?php elseif($data->a_npwp == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->npwp); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->npwp)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->npwp); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->npwp)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        

                                        
                                        <?php if(!empty($data->foto_kantor)): ?>
                                            <?php
                                                $pecah = explode('.', $data->foto_kantor);
                                                $foto_kantor = $pecah[1];
                                            ?>

                                            <?php if($foto_kantor == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_foto_kantor == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->foto_kantor); ?></label>
                                                    <?php elseif($data->a_foto_kantor == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->foto_kantor); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#foto_kantor"
                                                        class="btn btn-primary">Lihat
                                                    </a>
                                                </p>
                                            <?php elseif($foto_kantor == 'png' or $foto_kantor == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_foto_kantor == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->foto_kantor); ?></label>
                                                    <?php elseif($data->a_foto_kantor == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->foto_kantor); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->foto_kantor)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->foto_kantor); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->foto_kantor)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </form>
                            </div>


                            <div class="tab-pane active" id="data3" role="tabpanel">
                                <form class="md-float-material form-material">
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        

                                        <?php if(!empty($data->surat_ketertiban)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_ketertiban);
                                                $surat_ketertiban = $pecah[1];
                                            ?>

                                            <?php if($surat_ketertiban == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_ketertiban == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_ketertiban); ?></label>
                                                    <?php elseif($data->a_surat_ketertiban == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_ketertiban); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <p class="text-muted text-center p-b-5"><?php echo e($data->surat_ketertiban); ?>


                                                    <a data-toggle="modal" href="#surat_ketertiban"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_ketertiban == 'png' or $surat_ketertiban == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_ketertiban == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_ketertiban); ?></label>
                                                    <?php elseif($data->a_surat_ketertiban == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_ketertiban); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_ketertiban)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_ketertiban); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_ketertiban)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        


                                        

                                        <?php if(!empty($data->surat_tidak_avilasi)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_tidak_avilasi);
                                                $surat_tidak_avilasi = $pecah[1];
                                            ?>

                                            <?php if($surat_tidak_avilasi == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_tidak_avilasi == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_tidak_avilasi); ?></label>
                                                    <?php elseif($data->a_surat_tidak_avilasi == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_tidak_avilasi); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <p class="text-muted text-center p-b-5">
                                                    <?php echo e($data->surat_tidak_avilasi); ?>


                                                    <a data-toggle="modal" href="#surat_tidak_avilasi"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_tidak_avilasi == 'png' or $surat_tidak_avilasi == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_tidak_avilasi == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_tidak_avilasi); ?></label>
                                                    <?php elseif($data->a_surat_tidak_avilasi == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_tidak_avilasi); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_tidak_avilasi)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_tidak_avilasi); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_tidak_avilasi)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_konflik)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_konflik);
                                                $surat_konflik = $pecah[1];
                                            ?>

                                            <?php if($surat_konflik == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_konflik == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_konflik); ?></label>
                                                    <?php elseif($data->a_surat_konflik == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_konflik); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <a data-toggle="modal" href="#surat_konflik"
                                                    class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_konflik == 'png' or $surat_konflik == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_konflik == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_konflik); ?></label>
                                                    <?php elseif($data->a_surat_konflik == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_konflik); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_konflik)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_konflik); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_konflik)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_hak_cipta)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_hak_cipta);
                                                $surat_hak_cipta = $pecah[1];
                                            ?>

                                            <?php if($surat_hak_cipta == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_hak_cipta == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_hak_cipta); ?></label>
                                                    <?php elseif($data->a_surat_hak_cipta == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_hak_cipta); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <a data-toggle="modal" href="#surat_hak_cipta"
                                                    class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_hak_cipta == 'png' or $surat_hak_cipta == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_hak_cipta == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_hak_cipta); ?></label>
                                                    <?php elseif($data->a_surat_hak_cipta == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_hak_cipta); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_hak_cipta)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_hak_cipta); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_hak_cipta)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_laporan)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_laporan);
                                                $surat_laporan = $pecah[1];
                                            ?>

                                            <?php if($surat_laporan == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_laporan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_laporan); ?></label>
                                                    <?php elseif($data->a_surat_laporan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_laporan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">

                                                    <a data-toggle="modal" href="#surat_laporan"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_laporan == 'png' or $surat_laporan == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_laporan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_laporan); ?></label>
                                                    <?php elseif($data->a_surat_laporan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_laporan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_laporan)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_laporan); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_laporan)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </form>
                            </div>

                            <div class="tab-pane active" id="data4" role="tabpanel">
                                <form class="md-float-material form-material">
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        

                                        <?php if(!empty($data->surat_absah)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_absah);
                                                $surat_absah = $pecah[1];
                                            ?>

                                            <?php if($surat_absah == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_absah == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_absah); ?></label>
                                                    <?php elseif($data->a_surat_absah == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_absah); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_absah"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_absah == 'png' or $surat_absah == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_absah == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_absah); ?></label>
                                                    <?php elseif($data->a_surat_absah == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_absah); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_absah)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_absah); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_absah)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_rekom_agama)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_rekom_agama);
                                                $surat_rekom_agama = $pecah[1];
                                            ?>

                                            <?php if($surat_rekom_agama == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_agama == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_agama); ?></label>
                                                    <?php elseif($data->a_surat_rekom_agama == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_agama); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_rekom_agama"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_rekom_agama == 'png' or $surat_rekom_agama == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_agama == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_agama); ?></label>
                                                    <?php elseif($data->a_surat_rekom_agama == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_agama); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_agama)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_rekom_agama); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_agama)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_rekom_skpd)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_rekom_skpd);
                                                $surat_rekom_skpd = $pecah[1];
                                            ?>

                                            <?php if($surat_rekom_skpd == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_skpd == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_skpd); ?></label>
                                                    <?php elseif($data->a_surat_rekom_skpd == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_skpd); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_rekom_skpd"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_rekom_skpd == 'png' or $surat_rekom_skpd == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_skpd == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_skpd); ?></label>
                                                    <?php elseif($data->a_surat_rekom_skpd == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_skpd); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_skpd)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_rekom_skpd); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_skpd)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_rekom_skpd_kerja)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_rekom_skpd_kerja);
                                                $surat_rekom_skpd_kerja = $pecah[1];
                                            ?>

                                            <?php if($surat_rekom_skpd_kerja == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_skpd_kerja == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_skpd_kerja); ?></label>
                                                    <?php elseif($data->a_surat_rekom_skpd_kerja == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_skpd_kerja); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_rekom_skpd_kerja"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_rekom_skpd_kerja == 'png' or $surat_rekom_skpd_kerja == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_skpd_kerja == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_skpd_kerja); ?></label>
                                                    <?php elseif($data->a_surat_rekom_skpd_kerja == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_skpd_kerja); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_skpd_kerja)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_rekom_skpd_kerja); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_skpd_kerja)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_rekom_kesediaan)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_rekom_kesediaan);
                                                $surat_rekom_kesediaan = $pecah[1];
                                            ?>

                                            <?php if($surat_rekom_kesediaan == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_kesediaan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_kesediaan); ?></label>
                                                    <?php elseif($data->a_surat_rekom_kesediaan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_kesediaan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_rekom_kesediaan"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_rekom_kesediaan == 'png' or $surat_rekom_kesediaan == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_rekom_kesediaan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_rekom_kesediaan); ?></label>
                                                    <?php elseif($data->a_surat_rekom_kesediaan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_rekom_kesediaan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_kesediaan)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_rekom_kesediaan); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_rekom_kesediaan)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->surat_izasah)): ?>
                                            <?php
                                                $pecah = explode('.', $data->surat_izasah);
                                                $surat_izasah = $pecah[1];
                                            ?>

                                            <?php if($surat_izasah == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_izasah == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_izasah); ?></label>
                                                    <?php elseif($data->a_surat_izasah == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_izasah); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#surat_izasah"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($surat_izasah == 'png' or $surat_izasah == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_surat_izasah == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->surat_izasah); ?></label>
                                                    <?php elseif($data->a_surat_izasah == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->surat_izasah); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_izasah)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->surat_izasah); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->surat_izasah)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->skt)): ?>
                                            <?php
                                                $pecah = explode('.', $data->skt);
                                                $skt = $pecah[1];
                                            ?>

                                            <?php if($skt == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_skt == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->skt); ?></label>
                                                    <?php elseif($data->a_skt == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->skt); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>
                                                <a data-toggle="modal" href="#skt" class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($skt == 'png' or $skt == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_skt == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->skt); ?></label>
                                                    <?php elseif($data->a_skt == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->skt); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                


                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->skt)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->skt); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->skt)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        


                                        

                                        <?php if(!empty($data->tujuan)): ?>
                                            <?php
                                                $pecah = explode('.', $data->tujuan);
                                                $tujuan = $pecah[1];
                                            ?>

                                            <?php if($tujuan == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_tujuan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->tujuan); ?></label>
                                                    <?php elseif($data->a_tujuan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->tujuan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#tujuan" class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($tujuan == 'png' or $tujuan == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_tujuan == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->tujuan); ?></label>
                                                    <?php elseif($data->a_tujuan == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->tujuan); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->tujuan)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->tujuan); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->tujuan)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        

                                        

                                        <?php if(!empty($data->program)): ?>
                                            <?php
                                                $pecah = explode('.', $data->program);
                                                $program = $pecah[1];
                                            ?>

                                            <?php if($program == 'pdf'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_program == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->program); ?></label>
                                                    <?php elseif($data->a_program == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->program); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                <p class="text-muted text-center p-b-5">
                                                    <a data-toggle="modal" href="#program"
                                                        class="btn btn-primary">Lihat</a>
                                                </p>
                                            <?php elseif($program == 'png' or $program == 'jpg'): ?>
                                                <p class="text-muted text-center p-b-5">
                                                    <?php if($data->a_program == 0): ?>
                                                        <label class="label label-inverse-primary"><span
                                                                data-feather="loader"></span><?php echo e($data->program); ?></label>
                                                    <?php elseif($data->a_program == 1): ?>
                                                        <label class="label label-inverse-success"><span
                                                                data-feather="check-circle"></span><?php echo e($data->program); ?></label>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </p>

                                                
                                                </p>

                                                <div class="col-lg-12 col-sm-12">
                                                    <div class="thumbnail">
                                                        <div class="thumb">
                                                            <a href="<?php echo e(asset(auth()->user()->nama . '/' . $data->program)); ?>"
                                                                data-lightbox="1"
                                                                data-title="<?php echo e(auth()->user()->nama . '/' . $data->program); ?>">

                                                                <img src="<?php echo e(asset(auth()->user()->nama . '/' . $data->program)); ?>"
                                                                    alt="" class="img-fluid img-thumbnail mx-auto d-block"
                                                                    style="max-height: 200px;">


                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </form>
                            </div>


                        </div>
                        

                    </div>
                </div>
            </div>
        </div>



        


        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div id="akte_pendirian" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">
                                &times;
                            </button>
                            <h4 class="modal-title"><?php echo e($data->akte_pendirian); ?></h4>
                        </div>
                        <div class="modal-body">
                            <!-- <embed                                                                                                                                                                                                               /> -->
                            <embed src="<?php echo e(asset(auth()->user()->nama . '/' . $data->akte_pendirian)); ?>" frameborder="0"
                                width="100%" height="400px" />
                            <!--
                                                                            <!-- <object
                                                                            <div class="modal-footer">
                                                                                <button type="button" class="btn btn-default" data-dismiss="modal">
                                                                                    Close
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

                                                       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\2024\Documents\Laravel\kesbangpol\resources\views/user/dashboard.blade.php ENDPATH**/ ?>