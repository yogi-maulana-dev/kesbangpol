

<?php $__env->startSection('data'); ?>

data
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\2024\Documents\Laravel\kesbangpol\resources\views/user/data.blade.php ENDPATH**/ ?>